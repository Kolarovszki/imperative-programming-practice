#include<stdio.h>

int main() {
               //--i esetén más lenne?
    for(int i=0; 10>=--i; i+=2) {
        printf("Fut %d\n", i);
        // Vajon hányszor futle?
    } 

    return 0;
}
