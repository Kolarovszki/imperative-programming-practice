#include<stdio.h>

int main() {
    
    int i;
               
    for(i=0; i<=10; i++) {
        printf("Fut %d\n", i);
        // Vajon hányszor fut le?
        i++;
    } 

    return 0;
}