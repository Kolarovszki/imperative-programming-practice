#include<stdio.h>

int main() {
    
    for( ; ; ) {
        printf("Fut\n");
        if(1 != 0){
          break;
        }
    } 
    printf("Cikluson kívül!\n");

    return 0;
}
