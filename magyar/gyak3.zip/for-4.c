#include<stdio.h>

int main() {
    
    int i;
             //0 esetén mi lenne?  
    for(i=5; i=1; i--) {
        printf("Fut %d\n", i);
        // Vajon hányszor fut le?
    } 

    return 0;
}
