#include<stdio.h>
int main() {
    
    int j = 52;
    
    int i;
    for(int i=0; i<3; j=++i) {
        int k = 69;
        printf("%d ",j);
    }
    
    printf("%d\n", k);
    
    for(i=0; i<3; j=i++) {
        printf("%d ",j);
    }
    
    return 0;
}
